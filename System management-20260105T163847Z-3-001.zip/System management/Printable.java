package studentmanagement;

/**
 * Printable Interface - Demonstrates Abstraction via Interface
 */
public interface Printable {
    void printDetails();
}