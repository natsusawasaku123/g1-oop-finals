package studentmanagement;

/**
 * HonorStudent class - Demonstrates Method Overriding (Polymorphism)
 * Extends Student class
 */
public class HonorStudent extends Student {
    private double scholarshipAmount;
    
    // Default Constructor
    public HonorStudent() {
        super();
        this.scholarshipAmount = 0.0;
    }
    
    // Parameterized Constructor
    public HonorStudent(String schoolName, String studentId, String name, int age, 
                       GradeLevel gradeLevel, double[] grades, double scholarshipAmount) {
        super(schoolName, studentId, name, age, gradeLevel, grades);
        this.scholarshipAmount = scholarshipAmount;
    }
    
    public double getScholarshipAmount() {
        return scholarshipAmount;
    }
    
    public void setScholarshipAmount(double scholarshipAmount) {
        this.scholarshipAmount = scholarshipAmount;
    }
    
    // Method Overriding - Polymorphism
    @Override
    public void printDetails() {
        System.out.println("=== HONOR STUDENT Details ===");
        displaySchool();
        System.out.println("Student ID: " + getStudentId());
        getPersonInfo().displayInfo();
        System.out.println("Grade Level: " + getGradeLevel());
        System.out.println("Average Grade: " + String.format("%.2f", calculateAverage()));
        System.out.println("GPA: " + String.format("%.2f", calculateGPA()));
        System.out.println("Scholarship: $" + String.format("%.2f", scholarshipAmount));
        System.out.println("*** HONOR ROLL ***");
    }
    
    // Method Overriding - Different GPA calculation for honor students
    @Override
    public double calculateGPA() {
        // Honor students get a bonus in GPA calculation
        return (calculateAverage() / 25.0) + 0.5;
    }
}