package studentmanagement;

/**
 * Student class - Child class extending Person
 * Demonstrates: Inheritance, Polymorphism, Interface implementation
 * Constructor overloading, Method with parameters, Method returning value
 */
public class Student extends SchoolRecord implements Printable {
    // Encapsulation: Private attributes
    private String studentId;
    private Person personInfo;
    private GradeLevel gradeLevel;
    private double[] grades;
    
    // Default Constructor (Constructor Overloading #1)
    public Student() {
        super("Default School");
        this.studentId = "000000";
        this.personInfo = new Person();
        this.gradeLevel = GradeLevel.FIRST_YEAR;
        this.grades = new double[0];
    }
    
    // Parameterized Constructor (Constructor Overloading #2)
    public Student(String schoolName, String studentId, String name, int age, GradeLevel gradeLevel) {
        super(schoolName); // Using super() to call parent constructor
        this.studentId = studentId;
        this.personInfo = new Person(name, age);
        this.gradeLevel = gradeLevel;
        this.grades = new double[0];
    }
    
    // Parameterized Constructor with grades (Constructor Overloading #3)
    public Student(String schoolName, String studentId, String name, int age, GradeLevel gradeLevel, double[] grades) {
        super(schoolName); // Using super() to call parent constructor
        this.studentId = studentId;
        this.personInfo = new Person(name, age);
        this.gradeLevel = gradeLevel;
        this.grades = grades;
    }
    
    // Getters and Setters (Encapsulation)
    public String getStudentId() {
        return studentId;
    }
    
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public Person getPersonInfo() {
        return personInfo;
    }
    
    public void setPersonInfo(Person personInfo) {
        this.personInfo = personInfo;
    }
    
    public GradeLevel getGradeLevel() {
        return gradeLevel;
    }
    
    public void setGradeLevel(GradeLevel gradeLevel) {
        this.gradeLevel = gradeLevel;
    }
    
    public double[] getGrades() {
        return grades;
    }
    
    public void setGrades(double[] grades) {
        this.grades = grades;
    }
    
    // Method with parameters - Adds a grade to the student
    public void addGrade(double grade) {
        double[] newGrades = new double[grades.length + 1];
        for (int i = 0; i < grades.length; i++) {
            newGrades[i] = grades[i];
        }
        newGrades[grades.length] = grade;
        this.grades = newGrades;
    }
    
    // Method with parameters - Sets multiple grades at once
    public void setMultipleGrades(double[] newGrades) {
        this.grades = newGrades;
    }
    
    // Method returning a value - Calculates average grade
    public double calculateAverage() {
        if (grades.length == 0) {
            return 0.0;
        }
        
        double sum = 0;
        // For loop requirement
        for (int i = 0; i < grades.length; i++) {
            sum += grades[i];
        }
        
        return sum / grades.length;
    }
    
    // Abstract method implementation from SchoolRecord
    @Override
    public double calculateGPA() {
        return calculateAverage() / 25.0; // Simple GPA calculation (assuming 100 point scale)
    }
    
    // Interface method implementation from Printable
    @Override
    public void printDetails() {
        System.out.println("=== Student Details ===");
        displaySchool();
        System.out.println("Student ID: " + studentId);
        personInfo.displayInfo();
        System.out.println("Grade Level: " + gradeLevel);
        System.out.println("Average Grade: " + String.format("%.2f", calculateAverage()));
        System.out.println("GPA: " + String.format("%.2f", calculateGPA()));
    }
    
    // Object method using object data
    public void displayInfo() {
        printDetails();
    }
    
    // Method with parameter that returns a value
    public String getGradeStatus(double passingGrade) {
        double avg = calculateAverage();
        if (avg >= passingGrade) {
            return "PASSING";
        } else {
            return "NEEDS IMPROVEMENT";
        }
    }
}