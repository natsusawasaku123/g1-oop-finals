package studentmanagement;

/**
 * Main class - Student Management System
 * Demonstrates all required features:
 * - Control structures (for, for-each, break)
 * - 2D arrays
 * - Nested loops
 * - Array of objects
 * - Polymorphism (dynamic method dispatch)
 * - All OOP principles
 */
public class Main {
    
    public static void main(String[] args) {
        System.out.println("====================================");
        System.out.println("  STUDENT MANAGEMENT SYSTEM");
        System.out.println("====================================\n");
        
        // Array of Objects - Student array
        Student[] studentList = new Student[5];
        
        // Creating students with different constructors
        studentList[0] = new Student("Tech University", "S001", "Alice Johnson", 20, 
                                    GradeLevel.SECOND_YEAR, new double[]{85.5, 90.0, 88.5});
        
        studentList[1] = new Student("Tech University", "S002", "Bob Smith", 21, 
                                    GradeLevel.THIRD_YEAR, new double[]{78.0, 82.5, 80.0});
        
        studentList[2] = new HonorStudent("Tech University", "S003", "Charlie Brown", 19, 
                                         GradeLevel.FIRST_YEAR, new double[]{95.0, 98.0, 96.5}, 5000.0);
        
        studentList[3] = new Student("Tech University", "S004", "Diana Prince", 22, 
                                    GradeLevel.FOURTH_YEAR, new double[]{88.0, 91.0, 89.5});
        
        studentList[4] = new HonorStudent("Tech University", "S005", "Ethan Hunt", 20, 
                                         GradeLevel.SECOND_YEAR, new double[]{92.0, 94.5, 93.0}, 3500.0);
        
        // 2D Array - Grade table showing subjects and scores
        System.out.println("--- GRADE TABLE EXAMPLE (2D Array) ---");
        String[][] gradeTable = {
            {"Student", "Math", "Science", "English"},
            {"Alice", "85.5", "90.0", "88.5"},
            {"Bob", "78.0", "82.5", "80.0"},
            {"Charlie", "95.0", "98.0", "96.5"}
        };
        
        // Nested for loop - Display grade table
        System.out.println("\nGrade Table:");
        for (int i = 0; i < gradeTable.length; i++) {
            for (int j = 0; j < gradeTable[i].length; j++) {
                System.out.printf("%-12s", gradeTable[i][j]);
            }
            System.out.println();
        }
        System.out.println();
        
        // Display all students using for loop
        System.out.println("--- ALL STUDENTS (Using for loop) ---");
        for (int i = 0; i < studentList.length; i++) {
            System.out.println("\nStudent #" + (i + 1) + ":");
            // Polymorphism - Dynamic method dispatch
            studentList[i].printDetails();
            System.out.println();
        }
        
        // For-each loop - Display specific information
        System.out.println("\n--- STUDENT AVERAGES (Using for-each loop) ---");
        for (Student student : studentList) {
            System.out.println(student.getPersonInfo().getName() + " - Average: " + 
                             String.format("%.2f", student.calculateAverage()));
        }
        
        // Demonstrating break statement
        System.out.println("\n--- FINDING FIRST HONOR STUDENT (Using break) ---");
        for (int i = 0; i < studentList.length; i++) {
            if (studentList[i] instanceof HonorStudent) {
                System.out.println("First honor student found: " + 
                                 studentList[i].getPersonInfo().getName());
                break; // Break statement
            }
        }
        
        // Nested for-each loop - Compare all students with each other
        System.out.println("\n--- STUDENT COMPARISON (Nested for-each loop) ---");
        System.out.println("Students with higher average than others:");
        for (Student s1 : studentList) {
            int higherCount = 0;
            for (Student s2 : studentList) {
                if (s1 != s2 && s1.calculateAverage() > s2.calculateAverage()) {
                    higherCount++;
                }
            }
            if (higherCount > 0) {
                System.out.println(s1.getPersonInfo().getName() + " has higher average than " + 
                                 higherCount + " other student(s)");
            }
        }
        
        // Demonstrating method with parameters that returns a value
        System.out.println("\n--- GRADE STATUS CHECK (Method with parameters) ---");
        double passingGrade = 85.0;
        for (Student student : studentList) {
            String status = student.getGradeStatus(passingGrade);
            System.out.println(student.getPersonInfo().getName() + ": " + status);
        }
        
        // Demonstrating Enum usage
        System.out.println("\n--- STUDENTS BY GRADE LEVEL (Enum usage) ---");
        for (GradeLevel level : GradeLevel.values()) {
            System.out.println("\n" + level + ":");
            for (Student student : studentList) {
                if (student.getGradeLevel() == level) {
                    System.out.println("  - " + student.getPersonInfo().getName());
                }
            }
        }
        
        // Adding grades dynamically (method with parameters)
        System.out.println("\n--- ADDING NEW GRADE (Method with parameters) ---");
        System.out.println("Adding grade 92.0 to " + studentList[0].getPersonInfo().getName());
        System.out.println("Before: Average = " + String.format("%.2f", studentList[0].calculateAverage()));
        studentList[0].addGrade(92.0);
        System.out.println("After: Average = " + String.format("%.2f", studentList[0].calculateAverage()));
        
        // Demonstrating polymorphism with abstract class
        System.out.println("\n--- GPA CALCULATION (Abstract class method) ---");
        for (Student student : studentList) {
            SchoolRecord record = student; // Upcasting to abstract class
            System.out.println(student.getPersonInfo().getName() + " GPA: " + 
                             String.format("%.2f", record.calculateGPA()));
        }
        
        System.out.println("\n====================================");
        System.out.println("  SYSTEM DEMONSTRATION COMPLETE");
        System.out.println("====================================");
    }
}