package studentmanagement;

/**
 * SchoolRecord Abstract Class - Demonstrates Abstraction
 * Contains at least one abstract method
 */
public abstract class SchoolRecord {
    protected String schoolName;
    
    public SchoolRecord(String schoolName) {
        this.schoolName = schoolName;
    }
    
    // Abstract method - must be implemented by child classes
    public abstract double calculateGPA();
    
    // Concrete method
    public void displaySchool() {
        System.out.println("School: " + schoolName);
    }
}