package studentmanagement;

/**
 * Person class - Parent class demonstrating Inheritance
 * This class uses Encapsulation (private attributes with getters/setters)
 */
public class Person {
    // Encapsulation: Private attributes
    private String name;
    private int age;
    
    // Default Constructor
    public Person() {
        this.name = "Unknown";
        this.age = 0;
    }
    
    // Parameterized Constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    // Getters and Setters (Encapsulation)
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
    
    // Method that will be overridden (Polymorphism)
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}