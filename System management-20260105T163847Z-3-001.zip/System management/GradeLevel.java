package studentmanagement;

/**
 * GradeLevel Enum - Demonstrates use of Enum for constants
 */
public enum GradeLevel {
    FIRST_YEAR,
    SECOND_YEAR,
    THIRD_YEAR,
    FOURTH_YEAR,
    GRADUATE
}